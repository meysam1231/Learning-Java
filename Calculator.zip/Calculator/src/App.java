import java.util.Scanner;

class calc{
    public static void main(String args[]){
        Scanner me = new Scanner(System.in);
        double fnum,snum, answer;
        System.out.println("Enter first num: ");
        fnum = me.nextDouble();
        System.out.println("Enter second num: ");
        snum = me.nextDouble();
        answer = fnum + snum;
        System.out.println(answer);
        
    }
}
