import java.util.Scanner;

class calc{
    
    public static void main(String args[]){
        try (Scanner me = new Scanner(System.in)) {
            double fnum, snum;
            double answer = 0;
            String func = "";
            boolean correct = false;
            while(!correct) {
                System.out.println("What math function do you want to operate?");
                System.out.println("Type 'add' for addition");
                System.out.println("Type 'sub' for subtraction");
                System.out.println("Type 'mult' for multiplication");
                System.out.println("Type 'div' for division");
                func = me.next();
                System.out.println("Enter first num: ");
                fnum = me.nextDouble();
                System.out.println("Enter second num: ");
                snum = me.nextDouble();
                if(func.equals("add")){           
                    answer = fnum + snum;
                    correct = true;
                } else if(func.equals("sub")){            
                    answer = fnum - snum;
                    correct = true;
                } else if(func.equals("mult")){            
                    answer = fnum * snum;
                    correct = true;
                } else if(func.equals("div")){            
                    answer = fnum / snum;
                    correct = true;
                } else {
                    System.out.println("You have not inputted the function name correctly, please try again");
                    func = "";
                }
            }
            System.out.println(answer);
        }
    }
}

