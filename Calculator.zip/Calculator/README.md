This is a basic math operators calculator. 
The functions it offers are addition, subtraction, multiplication and division

It will first prompt you to input the first number, then it will prompt you to input the second. 

After inputting both numbers, it will output the resulting math operation of the two numbers.
